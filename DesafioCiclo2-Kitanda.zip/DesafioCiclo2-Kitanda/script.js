// -------------------soma valores das frutas ------------------------
 let frutas = [
     {fruta: "Maçã", preco: 3.36},
     {fruta: "Melão", preco: 6.36},
 ]

function listaFrutas(f){
  let total=0;
     for( let produto of f){
         for( let p  in produto){
             console.log(` ${p} -> ${produto[p]}` );
             if(produto[p] == produto.preco){
                 total+= produto.preco;
             }
         }
     }    
  console.log(total)
 }

 listaFrutas( frutas );

 // -------------------- fim da função soma frutas --------------------


 // ------------procedimento para capturar o item que foi clicado na tela----------------
 window.onload = function(){

    
    const ulPai = document.querySelectorAll("#ulPai");
    //console.log=(ulPai);
    
    ulPai.forEach(function(lista){ //percorre a lista como se fosse um for

         lista.addEventListener('click',function(elemento){

             alert(elemento.target.innerHTML); // mostra a o que foi clicado

         })     

     })
}
//------------------------ fim do procedimento-----------------------------------------------